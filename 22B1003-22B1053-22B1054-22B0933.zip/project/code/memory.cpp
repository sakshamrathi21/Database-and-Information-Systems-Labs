#include "memory.h" 

int current_timestamp = 0;
std::map<std::string, std::map<std::string, int>> count_of_num_accesses;