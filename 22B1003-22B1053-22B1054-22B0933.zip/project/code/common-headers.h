#ifndef COMMON_HEADERS_H
#define COMMON_HEADERS_H

#include<iostream>
#include <pqxx/pqxx>
#include <string>
#include <sstream>
#include <iomanip>
#include <readline/readline.h>
#include <readline/history.h>
#include <vector>
#include <algorithm>
#include <map>
#include <set>

#endif